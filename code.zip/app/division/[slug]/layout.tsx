import type React from "react"
export default function DivisionLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
